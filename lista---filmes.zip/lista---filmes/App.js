import React, { useState } from 'react';
import { View, Text, TextInput, Button, FlatList, StyleSheet, TouchableOpacity} from 'react-native';
import { Title, Paragraph, Card } from 'react-native-paper';

export default function App() {
  // useState pra salvar a lista de filmes.
  const [filmes, setFilmes] = useState([]); 
  

  const [novoFilme, setNovoFilme] = useState({
    // Adicionando elementos geralmente vistos em serviços de streaming
    titulo: '',
    genero: '',
    descricao: '', 
    avaliacao: '',
  });

  const addFilme = () => {
    // Método para adicionar novos filmes
    if (novoFilme.titulo && novoFilme.genero && novoFilme.avaliacao) {
      setFilmes([...filmes, novoFilme]);
      setNovoFilme({
        titulo: '',
        genero: '',
        descricao: '',
        avaliacao: '',
      });
    }
  };

  const deletarFilme = (index) => {
    // Método para deletar os filmes
    const novosFilmes = filmes.slice();
    novosFilmes.splice(index, 1);
    setFilmes(novosFilmes);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}> 🎬 FILMES 🍿  </Text>

      <View style={styles.formContainer}>
        <Text style={styles.subHeader}> ADICIONE UM FILME! </Text>
        <TextInput
          style={styles.input}
          placeholder="Título"
          value={novoFilme.titulo}
          onChangeText={(text) => setNovoFilme({ ...novoFilme, titulo: text })}
        />
      <TextInput
          style={styles.input}
          placeholder="Gênero"
          value={novoFilme.genero}
          onChangeText={(text) => setNovoFilme({ ...novoFilme, genero: text })}
        />
      <TextInput
          style={styles.input}
          placeholder="Descrição"
          value={novoFilme.descricao}
          onChangeText={(text) => setNovoFilme({ ...novoFilme, descricao: text })}
        />
      <TextInput
          style={styles.input}
          placeholder="Avaliação"
          value={novoFilme.avaliacao}
          onChangeText={(text) => setNovoFilme({ ...novoFilme, avaliacao: text })}
          keyboardType="numeric"
        />
      <Button title="Adicionar" onPress={addFilme} />
      </View>

      <Text style={styles.subHeader}>LISTA DE FILMES SALVOS:</Text>
      <FlatList
        data={filmes}
        renderItem={({ item, index }) => (
       <View style={styles.card}>
       <Title>{item.titulo}</Title>
       <Paragraph>Genero: {item.genero}</Paragraph>
       <Paragraph>Descrição: {item.descricao}</Paragraph>
       <Paragraph>Avaliação: {item.avaliacao}</Paragraph>
       <TouchableOpacity onPress={() => deletarFilme(index)}>
       <Text style={styles.excluirText}>Excluir</Text>
       </TouchableOpacity>
       </View>
        )}
        keyExtractor={(item, index) => index.toString()}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#9C8CA4',
    justifyContent: 'center',
  },
  formContainer: {
    marginBottom: 20,
    backgroundColor: '#ffffff',
    padding: 20,
    borderRadius: 8,
    elevation: 3,
  },
  header: {
    fontSize: 24,
    marginBottom: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  subHeader: {
    fontSize: 20,
    marginBottom: 10,
    fontWeight: 'bold',
    justifyContent: 'center',
    textAlign: 'center',
  },
  input: {
    height: 40,
    borderColor: '#000000',
    backgroundColor: '#ffffff',
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  card: {
    marginBottom: 10,
    backgroundColor: '#ffffff',
    padding: 10,
    borderRadius: 8,
    elevation: 5,
  },
  excluirText: {
    color: 'red',
  },
});
